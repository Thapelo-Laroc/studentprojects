<?php

use Illuminate\Http\Request;
use App\Models\Accommodation;
use App\Http\Controllers\StudentDashboardController;

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\StudentController;

use App\Http\Controllers\LecturerController;
use App\Http\Controllers\ResearchController;
use App\Http\Controllers\SuperAdminController;
use App\Http\Controllers\AccommodationController;
use App\Http\Controllers\Auth\StudentRegisterController;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('student.dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});


// routes/web.php

// Route::middleware(['auth', 'role:super_admin'])->group(function () {
//     Route::get('/super-admin', [SuperAdminController::class, 'index'])->name('super-admin.dashboard');
// });

// Route::middleware(['auth', 'role:lecturer'])->group(function () {
//     Route::get('/lecturer', [LecturerController::class, 'index'])->name('lecturer.dashboard');
// });

// Route::middleware(['auth', 'role:student'])->group(function () {
//     Route::get('/student', [StudentController::class, 'index'])->name('student.dashboard');
// });


// routes/web.php

Route::middleware(['auth', 'role:super_admin'])->group(function () {
    Route::get('/super-admin', [SuperAdminController::class, 'index'])->name('super-admin.dashboard');
});

Route::middleware(['auth', 'role:lecturer'])->group(function () {
    Route::get('/lecturer', [LecturerController::class, 'index'])->name('lecturer.dashboard');
});

Route::middleware(['auth', 'role:student'])->group(function () {
    Route::get('/student', [StudentController::class, 'index'])->name('student.dashboard');
});



// Accommodation Routes
// routes/web.php

Route::middleware(['auth', 'role:lecturer'])->group(function () {
    Route::get('/accommodations/create', [AccommodationController::class, 'create'])->name('accommodations.create');
    Route::post('/accommodations', [AccommodationController::class, 'store'])->name('accommodations.store');
});

Route::middleware(['auth', 'role:super_admin,student'])->group(function () {
    Route::get('/accommodations', [AccommodationController::class, 'index'])->name('accommodations.index');

    Route::get('/student/dashboard', [StudentController::class, 'dashboard'])->name('student.dashboard');

    Route::post('/accommodations/{id}/enroll', [AccommodationController::class, 'enroll'])->name('accommodations.enroll');

    Route::get('/accommodations/search', function (Request $request) {
        // Retrieve the search query from the request
        $query = $request->input('query');
    
        // Search the database for accommodations matching the query
        $accommodations = Accommodation::where('name', 'LIKE', "%{$query}%")
                                        ->orWhere('address', 'LIKE', "%{$query}%")
                                        ->with('images')
                                        ->get();
    
        // Return the search results to the view
        return view('accommodations.accommodation-search-results', compact('accommodations'));
    })->name('accommodations.search');
});

Route::get('/accommodations/{id}', [AccommodationController::class, 'show'])->name('accommodations.show');





Route::get('/footer-test', function () {
    return view('footer-test');
});

Route::get('/student/dashboard', [StudentController::class, 'dashboard'])->name('student.dashboard');



Route::post('/admin/create-lecturer', [SuperAdminController::class, 'createLecturer'])->name('admin.createLecturer');



// Route to display all lecturers
Route::get('/admin/dashboard', [SuperAdminController::class, 'showLecturers'])->name('admin.dashboard');


// Route to delete a lecturer
Route::delete('/admin/dashboard/{id}', [SuperAdminController::class, 'deleteLecturer'])->name('admin.deleteLecturer');


// Student submits research
Route::post('/student/publish', [ResearchController::class, 'submitResearch'])->name('student.submitResearch');
Route::get('student/publish', [ResearchController::class, 'showPublishForm'])->name('student.publish');

// Lecturer views and approves research
Route::get('/lecturer/publications', [ResearchController::class, 'viewSubmissions'])->name('lecturer.viewSubmissions');
Route::post('/lecturer/publications/{id}/approve', [ResearchController::class, 'approveResearch'])->name('lecturer.approveResearch');

// Students view approved research
Route::get('/published', [ResearchController::class, 'viewApprovedResearch'])->name('published.research');


// student registration

Route::get('student/register', [StudentRegisterController::class, 'showRegistrationForm'])->name('student.register');
Route::post('student/register', [StudentRegisterController::class, 'register'])->name('student.register.submit');

Route::get('student/dashboard', [StudentDashboardController::class, 'index'])->name('student.dashboard')->middleware('auth:student');

Route::get('student/publish', [ResearchController::class, 'showPublishForm'])->name('student.publish');
Route::post('student/publish', [ResearchController::class, 'submitResearch'])->name('student.publish.submit');


Route::get('student/publish', [ResearchController::class, 'showPublishForm'])->name('student.publish');
Route::post('student/publish', [ResearchController::class, 'submitResearch'])->name('student.publish.submit');


Route::get('lecturer/publications', [ResearchController::class, 'viewSubmissions'])->name('lecturer.publications');

Route::get('published/published', [ResearchController::class, 'viewPublished'])->name('published.published');


require __DIR__.'/auth.php';
