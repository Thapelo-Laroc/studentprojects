<?php

// In app/Models/Lecturer.php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Lecturer extends Model
{
    // Define table if it's not the plural form of the model name
    protected $table = 'users'; // Adjust if necessary
}
