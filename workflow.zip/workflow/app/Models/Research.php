<?php

namespace App\Models;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Research extends Model
{
    use HasFactory;

    // Explicitly set the table name
    protected $table = 'researches';

    protected $fillable = ['student_id', 'title', 'content', 'file', 'is_approved'];

    // Relationship with User (Student)
    public function student()
    {
        return $this->belongsTo(User::class);
    }
}
