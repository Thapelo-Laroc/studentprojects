<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class StudentDashboardController extends Controller
{
    public function __construct()
    {
        // Ensure the user is authenticated with the 'web' guard
        $this->middleware('auth:web');
    }

    public function index()
    {
        // Check if the authenticated user has the role 'student'
        if (Auth::check() && Auth::user()->role === 'student') {
            return view('student.dashboard');
        }

        return redirect()->route('login'); // Redirect to login if not a student
    }
}


