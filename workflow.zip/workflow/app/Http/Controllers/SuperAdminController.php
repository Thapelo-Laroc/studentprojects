<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class SuperAdminController extends Controller
{
    public function index()
{
    return view('super-admin.dashboard');
}

public function createLecturer(Request $request)
{
    // Validate form inputs
    $request->validate([
        'name' => 'required|string|max:255',
        'email' => 'required|string|email|max:255|unique:users',
    ]);

    // Generate a random password with the prefix 'Ump'
    $randomPassword = 'Ump' . Str::random(8);

    // Create the lecturer user
    $lecturer = User::create([
        'name' => $request->name,
        'email' => $request->email,
        'password' => Hash::make($randomPassword),
        'role' => 'lecturer',  // Set role as lecturer
    ]);

    // Optionally, send an email with the credentials (optional step)
    // Mail::to($lecturer->email)->send(new LecturerCreated($lecturer, $randomPassword));

     // Store lecturer details and the password in session to display on the dashboard
     session()->flash('lecturerDetails', [
        'name' => $lecturer->name,
        'email' => $lecturer->email,
        'role' => $lecturer->role,
        'password' => $randomPassword,  // Display the raw password
    ]);

    return redirect()->back()->with('success', 'Lecturer created successfully with password: ' . $randomPassword);
}


public function showLecturers()
{
    // Fetch all users where role is 'lecturer'
    $lecturers = User::where('role', 'lecturer')->get();
    
    // Return view with lecturers
    return view('admin.dashboard', compact('lecturers'));
}

public function deleteLecturer($id)
{
    // Find the lecturer by ID and delete
    $lecturer = User::findOrFail($id);
    $lecturer->delete();

    // Redirect back with a success message
    return redirect()->back()->with('success', 'Lecturer deleted successfully');
}
}
