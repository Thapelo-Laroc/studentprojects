<?php

namespace App\Http\Controllers;

use App\Models\Research;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ResearchController extends Controller
{
    // Student submits research
    public function submitResearch(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'content' => 'nullable',
            'file' => 'nullable|mimes:pdf,doc,docx|max:2048',
        ]);

        $filePath = null;
        if ($request->hasFile('file')) {
            $filePath = $request->file('file')->store('research_files', 'public');
        }

        Research::create([
            'student_id' => Auth::id(),
            'title' => $request->title,
            'content' => $request->content,
            'file' => $filePath,
        ]);

        return redirect()->back()->with('success', 'Research submitted successfully');
    }

    // Lecturer views submissions
    public function viewSubmissions()
    {
        $researches = Research::where('is_approved', false)->get(); // Unapproved research
        return view('lecturer.publications', compact('researches'));
    }

    // Lecturer approves research
    public function approveResearch($id)
    {
        $research = Research::find($id);
        $research->update(['is_approved' => true]);

        return redirect()->back()->with('success', 'Research approved successfully');
    }

    // Students view approved research
    public function viewApprovedResearch()
    {
        $researches = Research::where('is_approved', true)->get(); // Only approved research
        return view('published.published', compact('researches'));
    }


    public function showPublishForm()
    {
        return view('student.publish');  // Make sure the view exists in the correct folder
    }

    public function viewPublished()
    {
        $researches = Research::where('is_approved', true)->get(); // approved research
        return view('published.published', compact('researches'));
    }
}
