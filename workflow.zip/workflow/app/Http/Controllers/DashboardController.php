<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
   // In your DashboardController.php
    public function studentDashboard()
    {
        $lecturersCount = User::where('role', 'lecturer')->count();
        $studentsCount = User::where('role', 'student')->count();

        return view('student.dashboard', compact('lecturersCount', 'studentsCount'));
    }

    public function lecturerDashboard()
    {
        $lecturersCount = User::where('role', 'lecturer')->count();
        $studentsCount = User::where('role', 'student')->count();

        return view('lecturer.dashboard', compact('lecturersCount', 'studentsCount'));
    }

}

