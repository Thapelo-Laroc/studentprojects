


<!doctype html>
<html lang="en">
  <head>
  	<title>Login</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700&display=swap" rel="stylesheet">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<link rel="stylesheet" href="../assets/css/style.css">
    

	</head>
    <div class="background-container">
	<body class="img js-fullheight" style="background-image: url(../assets/images/ump.jpg); background-color: #00000060">
	<section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-6 text-center mb-5">
					<img src="../assets/img/UMP Icon.webp" alt="University of Mpumalanga Logo" width="240">
				</div>
			</div>
			<div class="row justify-content-center">
				<div class="col-md-6 col-lg-4">
					<div class="login-wrap p-0">
		      	<h3 class="mb-4 text-center">Have an account? Login &#x1F447;</h3>
		      	<form method="POST" action="<?php echo e(route('login')); ?>" class="signin-form">
                    <?php echo csrf_field(); ?>

		      		<div class="form-group">
		      			<input type="email" id="email" class="form-control" placeholder="Email" name="email" :value="old('email')" required autofocus autocomplete="username">
		      		</div>

	            <div class="form-group">
	              <input id="password" type="password" class="form-control" placeholder="Password" name="password" required autocomplete="current-password">
	              <span toggle="#password-field" class="fa fa-fw fa-eye field-icon toggle-password"></span>
                  <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('password'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('password')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
	            </div>


                

            



	            <div class="form-group">
	            	<button type="submit" class="form-control submit px-3" style="background-color: #aa0011">Sign In</button>
	            </div>
	            <div class="form-group d-md-flex">
	            	<div class="w-50">
		            	<label class="checkbox-wrap checkbox-primary">Remember Me
									  <input type="checkbox" checked>
									  <span class="checkmark"></span>
									</label>
								</div>
								<div class="w-50 text-md-right">
                                    <?php if(Route::has('password.request')): ?>
									    <a href="<?php echo e(route('password.request')); ?>" style="color: #fff">Forgot Password</a>
                                    <?php endif; ?>
								</div>


	            </div>
	          </form>
	          <p class="w-100 text-center">&mdash; Or Register &mdash;</p>
	          <div class="social d-flex text-center">
	          	<a href="<?php echo e(route('register')); ?>" class="px-2 py-2 rounded" style="background-color:#00771c;"><span class="ion-logo-facebook mr-2"></span> Register</a>
	          </div>
		      </div>
				</div>
			</div>
		</div>
	</section>

	<script src="js/jquery.min.js"></script>
  <script src="js/popper.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/main.js"></script>

	</body>
    </div>
</html>

<?php /**PATH C:\Users\dev\Documents\student projects\student-accommodation\resources\views/auth/login.blade.php ENDPATH**/ ?>